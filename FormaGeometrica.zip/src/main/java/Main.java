public class Main {
  public static void main(String[] args) {
  } abstract class FormaGeometrica {
    protected String tipo;

    public FormaGeometrica(String tipo) {
        this.tipo = tipo;
    }
   public abstract double calcularArea();
      public abstract double calcularPerimetro();
  } Retangulo retangulo = new Retangulo(5,3);
System.out.println(Area do retângulo: " + retangulo.calcularArea()" Perimetro " retangulo.calcularPerimetro"

Triangulo triangulo = new Triangulo (3,4,5);
System.out.Println("Area do Triangulo:" + triangulo.calcularArea()+ "Perimetro: " + triangulo.calcularPerimetro()
                
  class Triangulo extends FormaGeometrica {
    private double base;
    private double altura;

    public Triangulo(String tipo, double base, double altura) {
        super(tipo);
        this.base = base;
        this.altura = altura;
    }

    public double calcularArea() {
        return (base * altura) / 2;
    }

    public double calcularPerimetro() {
        return 3 * base;
    }
  }

  class Retangulo extends FormaGeometrica {
    private double lado1;
    private double lado2;

    public Retangulo(String tipo, double lado1, double lado2) {
        super(tipo);
        this.lado1 = lado1;
        this.lado2 = lado2;
    }

    public double calcularArea() {
        return lado1 * lado2;
    }

    public double calcularPerimetro() {
        return 2 * (lado1 + lado2);
    }
  }
  public class main {
    public static void main(String[] args) {
        Triangulo triangulo = new Triangulo("Triângulo", 5, 4);
        Retangulo retangulo = new Retangulo("Retângulo", 3, 6);

        System.out.println("Área do Triângulo: " + triangulo.calcularArea());
        System.out.println("Perímetro do Triângulo: " + triangulo.calcularPerimetro());
        System.out.println("Área do Retângulo: " + retangulo.calcularArea());
        System.out.println("Perímetro do Retângulo: " + retangulo.calcularPerimetro());
    }
  }